
const WebSocket = require('ws');
const PORT = process.env.PORT || 8080;
const wss = new WebSocket.Server({ port: PORT });

const rooms = {};

wss.on('connection', function connection(ws) {
  ws.on('message', function incoming(message) {
    let data = {};
    try {
      data = JSON.parse(message);
    } catch (e) {
      return;
    }

    if (data.type === 'join') {
      const { room, playerName } = data;
      ws.room = room;
      ws.playerName = playerName;

      if (!rooms[room]) rooms[room] = [];
      rooms[room].push(ws);

      rooms[room].forEach(client => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ type: 'peer-joined', playerName }));
        }
      });
    }

    if (data.type === 'signal' && ws.room) {
      rooms[ws.room].forEach(client => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ type: 'signal', signal: data.signal, from: ws.playerName }));
        }
      });
    }
  });

  ws.on('close', function () {
    const room = ws.room;
    if (room && rooms[room]) {
      rooms[room] = rooms[room].filter(client => client !== ws);
    }
  });
});

console.log(`Signaling server running on port ${PORT}`);
